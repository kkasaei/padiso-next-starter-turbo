<?php
/**
 * Plugin Name: SearchFIT
 * Plugin URI: https://searchfit.ai
 * Description: Receive articles via webhook API to automatically create WordPress posts with images, categories, and tags.
 * Version: 1.0.0
 * Author: SearchFIT
 * Author URI: https://searchfit.ai
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: searchfit
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Network: false
 *
 * @package SearchFIT
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants.
define( 'SEARCHFIT_VERSION', '1.0.0' );
define( 'SEARCHFIT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SEARCHFIT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SEARCHFIT_PLUGIN_FILE', __FILE__ );

/**
 * Main SearchFIT Plugin Class
 *
 * @since 1.0.0
 */
class SearchFIT {

    /**
     * Instance of this class.
     *
     * @var SearchFIT
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     *
     * @return SearchFIT
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->load_includes();
        $this->init_hooks();
    }

    /**
     * Load plugin includes.
     */
    private function load_includes() {
        require_once SEARCHFIT_PLUGIN_DIR . 'includes/class-searchfit-webhook.php';
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks() {
        // Activation and deactivation hooks.
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

        // Load textdomain.
        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

        // Admin hooks.
        if ( is_admin() ) {
            add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
            add_action( 'wp_ajax_searchfit_regenerate_api_key', array( $this, 'ajax_regenerate_api_key' ) );
        }
    }

    /**
     * Load plugin textdomain.
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'searchfit',
            false,
            dirname( plugin_basename( __FILE__ ) ) . '/languages'
        );
    }

    /**
     * Plugin activation.
     */
    public function activate() {
        // Set plugin version.
        add_option( 'searchfit_version', SEARCHFIT_VERSION );

        // Generate webhook API key if it doesn't exist.
        if ( ! get_option( 'searchfit_webhook_api_key' ) ) {
            $api_key = SearchFIT_Webhook::generate_api_key();
            add_option( 'searchfit_webhook_api_key', $api_key );
        }

        // Flush rewrite rules for REST API.
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation.
     */
    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Add admin menu.
     */
    public function add_admin_menu() {
        $icon_url = $this->get_menu_icon();

        add_menu_page(
            __( 'SearchFIT', 'searchfit' ),
            __( 'SearchFIT', 'searchfit' ),
            'manage_options',
            'searchfit',
            array( $this, 'render_admin_page' ),
            $icon_url,
            30
        );
    }

    /**
     * Get menu icon as data URI.
     *
     * @return string
     */
    private function get_menu_icon() {
        return plugins_url( 'assets/images/logo.png', __FILE__ );
    }

    /**
     * Render admin page.
     */
    public function render_admin_page() {
        // Check user capabilities.
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        include SEARCHFIT_PLUGIN_DIR . 'admin/views/admin-page.php';
    }

    /**
     * Enqueue admin scripts and styles.
     *
     * @param string $hook The current admin page hook.
     */
    public function enqueue_admin_scripts( $hook ) {
        // Only load on SearchFIT admin page.
        if ( 'toplevel_page_searchfit' !== $hook ) {
            return;
        }

        wp_enqueue_style(
            'searchfit-admin',
            SEARCHFIT_PLUGIN_URL . 'assets/css/searchfit-admin.css',
            array(),
            SEARCHFIT_VERSION
        );

        wp_enqueue_script(
            'searchfit-admin',
            SEARCHFIT_PLUGIN_URL . 'assets/js/searchfit.js',
            array( 'jquery' ),
            SEARCHFIT_VERSION,
            true
        );

        wp_localize_script(
            'searchfit-admin',
            'searchfitAdmin',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'searchfit_regenerate_api_key' ),
                'i18n'    => array(
                    'copied'            => __( 'Copied!', 'searchfit' ),
                    'copyFailed'        => __( 'Failed to copy', 'searchfit' ),
                    'regenerateConfirm' => __( 'Are you sure you want to regenerate the API key? The old key will stop working immediately.', 'searchfit' ),
                    'regenerating'      => __( 'Regenerating...', 'searchfit' ),
                    'regenerateError'   => __( 'Failed to regenerate API key. Please try again.', 'searchfit' ),
                ),
            )
        );
    }

    /**
     * AJAX handler for regenerating webhook API key.
     */
    public function ajax_regenerate_api_key() {
        // Verify nonce.
        if ( ! check_ajax_referer( 'searchfit_regenerate_api_key', 'nonce', false ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'Security check failed.', 'searchfit' ),
                )
            );
        }

        // Check permissions.
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'You do not have permission to perform this action.', 'searchfit' ),
                )
            );
        }

        // Generate new API key.
        $new_api_key = SearchFIT_Webhook::generate_api_key();

        // Update the option.
        update_option( 'searchfit_webhook_api_key', $new_api_key );

        wp_send_json_success(
            array(
                'message' => __( 'API key regenerated successfully.', 'searchfit' ),
                'api_key' => $new_api_key,
            )
        );
    }
}

/**
 * Initialize the plugin.
 *
 * @return SearchFIT
 */
function searchfit_init() {
    return SearchFIT::get_instance();
}

// Start the plugin.
searchfit_init();
