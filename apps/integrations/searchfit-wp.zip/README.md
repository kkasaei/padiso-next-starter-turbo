# SearchFIT

A WordPress plugin that provides a secure webhook API for programmatically creating posts from external services.

## Features

- **Secure API Key Authentication** - Auto-generated API keys with regeneration support
- **Full Post Creation** - Create posts with title, content, excerpt, categories, and tags
- **Image Support** - Automatically download and attach featured images and content images
- **Health Check Endpoint** - Verify API connectivity

## Installation

1. Upload the `searchfit` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress admin
3. Go to **SearchFIT** in the admin menu to view your API credentials

## API Usage

### Create an Article

```bash
curl -X POST "https://yoursite.com/wp-json/searchfit/v1/articles" \
  -H "Content-Type: application/json" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY" \
  -d '{
    "title": "My Article Title",
    "content": "<p>Article content here...</p>",
    "status": "draft",
    "categories": ["News"],
    "tags": ["important"]
  }'
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `title` | string | Yes | Article title |
| `content` | string | Yes | Article content (HTML) |
| `status` | string | No | `draft`, `pending`, or `publish` (default: `draft`) |
| `excerpt` | string | No | Article excerpt |
| `categories` | array | No | Category names or IDs |
| `tags` | array | No | Tag names |
| `featured_image_url` | string | No | URL of featured image |

### Health Check

```bash
curl "https://yoursite.com/wp-json/searchfit/v1/health" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY"
```

## Requirements

- WordPress 5.0+
- PHP 7.4+

## License

GPL v2 or later
