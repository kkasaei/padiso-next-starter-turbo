=== SearchFIT ===
Contributors: searchfit
Donate link: https://searchfit.ai
Tags: seo, ai, content automation, webhook, api
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automate your WordPress content with AI. Receive articles via secure webhook API to create posts with images, categories, and tags.

== Description ==

### SearchFIT – AI-Powered Content Automation for WordPress ###

**The easiest way to automate content creation with AI tools** 🚀
★★★★★

SearchFIT provides a **secure webhook API** that allows you to programmatically create WordPress posts from AI assistants, automation tools, or custom applications. Perfect for **AI-powered content workflows** with ChatGPT, Claude, Perplexity, and other AI systems.

[youtube https://www.youtube.com/watch?v=YOUR_VIDEO_ID]

### Why SearchFIT? ###

In the age of AI, content creation is evolving rapidly. **Answer Engine Optimization (AEO)** and **Generative Engine Optimization (GEO)** are becoming essential for modern SEO strategies. SearchFIT bridges the gap between your AI content generation tools and your WordPress website.

### 🔥 Key Features ###

= Secure API Authentication =
* **Auto-generated API Keys** – Cryptographically secure keys generated automatically
* **One-click Regeneration** – Instantly refresh your API key if compromised
* **Multiple Auth Methods** – Support for both custom header and Bearer token authentication

= Full Content Control =
* **Create Complete Posts** – Title, content, excerpt, and more
* **Smart Categorization** – Auto-create categories or use existing ones
* **Tag Management** – Automatically assign tags to your posts
* **Draft Mode** – Create posts as drafts, pending review, or publish immediately

= Advanced Image Handling =
* **Featured Images** – Automatically download and attach featured images
* **Content Images** – Process inline images with proper WordPress integration
* **SEO-Optimized** – Support for alt text, captions, and image metadata
* **Placeholder System** – Intelligent image replacement within content

= Developer-Friendly =
* **REST API** – Modern WordPress REST API integration
* **Comprehensive Documentation** – In-app documentation with code examples
* **Health Check Endpoint** – Verify API connectivity before sending content
* **Activity Logging** – Track all webhook submissions

### 📈 Perfect For ###

✔ **AI Content Generation** – Use with ChatGPT, Claude, Perplexity, or any AI
✔ **Answer Engine Optimization (AEO)** – Create content optimized for AI search
✔ **Generative Engine Optimization (GEO)** – Stay ahead in generative search results
✔ **Content Automation** – Build automated content pipelines
✔ **Headless WordPress** – External CMS and decoupled setups
✔ **Content Syndication** – Automated content distribution
✔ **Marketing Automation** – Connect with Zapier, Make, n8n, and more
✔ **Custom Applications** – Any system that can make HTTP requests

### 🎯 Use Cases ###

**Bloggers & Content Creators**
Automate your content workflow by connecting AI writing tools directly to WordPress.

**Digital Agencies**
Scale content production across multiple client sites with programmatic publishing.

**eCommerce Stores**
Generate product descriptions, blog posts, and SEO content automatically.

**News & Media Sites**
Rapidly publish AI-assisted articles while maintaining editorial control with draft mode.

### 🔒 Security First ###

Security is our top priority. SearchFIT uses:

* Cryptographically secure API key generation
* Timing-safe comparison to prevent timing attacks
* WordPress nonce verification for admin actions
* Proper capability checks for all operations
* Sanitization and validation of all inputs

### 🚀 Quick Start ###

1. Install and activate SearchFIT
2. Go to SearchFIT in your admin menu
3. Copy your API Key and Webhook URL
4. Send a POST request with your content

That's it! Your AI-generated content flows directly into WordPress.

== Installation ==

= Automatic Installation =

1. Go to **Plugins > Add New** in your WordPress admin
2. Search for **SearchFIT**
3. Click **Install Now** and then **Activate**

= Manual Installation =

1. Download the plugin zip file
2. Go to **Plugins > Add New > Upload Plugin**
3. Choose the zip file and click **Install Now**
4. Activate the plugin

= After Activation =

1. Navigate to **SearchFIT** in your WordPress admin menu
2. Your API credentials are automatically generated
3. Copy the **API Key** and **Webhook URL**
4. Start sending content via the API!

== Frequently Asked Questions ==

= How do I get my API key? =

After activating the plugin, go to SearchFIT in your WordPress admin menu. Your API key is displayed there and can be copied with one click. The key is automatically generated during plugin activation.

= Can I regenerate my API key? =

Yes! Click "Regenerate API Key" on the settings page. Please note that the old key will stop working immediately, so update your integrations before regenerating.

= What post statuses are supported? =

You can create posts with the following statuses:
* `draft` – Saved but not published (default)
* `pending` – Awaiting editorial review
* `publish` – Published immediately

= How do featured images work? =

Include a `featured_image_url` parameter with a public image URL, or use the advanced `featured_image` object with metadata. The plugin will download the image, add it to your Media Library, and set it as the featured image.

= Is the API secure? =

Absolutely! All requests require a valid API key. Keys are auto-generated using PHP's `random_bytes()` function for cryptographic security. The plugin uses timing-safe comparison to prevent timing attacks.

= Can I use this with AI tools? =

Yes! SearchFIT is specifically designed for AI-powered workflows. Use it with:
* ChatGPT & OpenAI
* Claude (Anthropic)
* Perplexity
* Google Gemini
* Any AI or automation tool that can make HTTP requests

= What happens to categories that don't exist? =

If you specify a category name that doesn't exist, SearchFIT will automatically create it for you. You can also use existing category IDs.

= Does it support custom post types? =

Currently, SearchFIT creates standard WordPress posts. Support for custom post types is planned for a future release.

= Can I set custom meta fields? =

Yes! Use the `meta` parameter to set custom meta fields. All fields are prefixed with `searchfit_` to avoid conflicts.

= Is there a rate limit? =

SearchFIT doesn't impose rate limits. However, your hosting provider may have their own limits on API requests.

= Where can I get support? =

Visit [searchfit.ai](https://searchfit.ai) for documentation and support resources. You can also use the WordPress.org support forum.

== Screenshots ==

1. **Dashboard Overview** – Your API credentials at a glance. Copy your API key and webhook URL with a single click.
2. **API Documentation Panel** – Interactive documentation with code examples and endpoint reference right in your WordPress admin.
3. **Endpoint Reference** – View all available endpoints, HTTP methods, and their descriptions.
4. **Request Parameters** – Complete reference of all supported fields with type information and requirements.
5. **Success Response** – Example of what the API returns after successfully creating a post.

== Changelog ==

= 1.0.0 =
* 🎉 Initial release
* ✅ Webhook API for article creation
* ✅ Secure API key authentication
* ✅ Featured image support with metadata
* ✅ Content image processing with placeholders
* ✅ Categories and tags support
* ✅ Draft, pending, and publish status options
* ✅ Health check endpoint
* ✅ Activity logging
* ✅ Beautiful admin interface with copy-to-clipboard functionality

== Upgrade Notice ==

= 1.0.0 =
Initial release of SearchFIT. Install now to automate your AI content workflow!

== API Reference ==

For complete API documentation with code examples in multiple languages, visit [searchfit.ai/docs](https://searchfit.ai/docs).

**Quick Example:**

`
curl -X POST "https://yoursite.com/wp-json/searchfit/v1/articles" \
  -H "Content-Type: application/json" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY" \
  -d '{
    "title": "My AI-Generated Article",
    "content": "<p>Your content here...</p>",
    "status": "draft",
    "categories": ["AI", "Technology"],
    "tags": ["ai-content", "automation"]
  }'
`

== Privacy Policy ==

SearchFIT does not collect or transmit any personal data. All operations are performed locally on your WordPress installation. API keys and webhook logs are stored in your WordPress database and are never transmitted to external servers.
