# SearchFIT – AI Content Automation & Webhook API for WordPress

[![WordPress Plugin](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)](https://wordpress.org/plugins/searchfit/)
[![PHP Version](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)](https://www.php.net/)
[![License](https://img.shields.io/badge/License-GPL%20v2-green.svg)](https://www.gnu.org/licenses/gpl-2.0.html)

Automate your WordPress content with AI. Receive articles via secure webhook API to create posts with images, categories, and tags. Perfect for ChatGPT, Claude, Perplexity, and AI content workflows.

![SearchFIT Banner](assets/images/banner-772x250.png)

## 🚀 Features

- **Secure API Key Authentication** - Cryptographically secure auto-generated API keys
- **Full Post Creation** - Create posts with title, content, excerpt, categories, and tags
- **Advanced Image Support** - Featured images and content images with SEO metadata
- **Flexible Post Status** - Create as draft, pending review, or publish immediately
- **Health Check Endpoint** - Verify API connectivity before sending content
- **Activity Logging** - Track all webhook submissions

## 📦 Installation

### From WordPress.org (Recommended)
1. Go to **Plugins > Add New** in your WordPress admin
2. Search for **SearchFIT**
3. Click **Install Now** and then **Activate**

### Manual Installation
1. Download the plugin ZIP file
2. Go to **Plugins > Add New > Upload Plugin**
3. Upload the ZIP file and click **Install Now**
4. Activate the plugin

## 🔧 Configuration

1. Navigate to **SearchFIT** in your WordPress admin menu
2. Copy your **API Key** and **Webhook URL**
3. Use these credentials in your external service or AI tool

## 📡 API Usage

### Create an Article

```bash
curl -X POST "https://yoursite.com/wp-json/searchfit/v1/articles" \
  -H "Content-Type: application/json" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY" \
  -d '{
    "title": "My AI-Generated Article",
    "content": "<p>Your content here...</p>",
    "status": "draft",
    "categories": ["AI", "Technology"],
    "tags": ["ai-content", "automation"],
    "featured_image_url": "https://example.com/image.jpg"
  }'
```

### Authentication

Include your API key in one of these headers:
```
X-SearchFIT-API-Key: YOUR_API_KEY
```
or
```
Authorization: Bearer YOUR_API_KEY
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `title` | string | ✅ Yes | Article title |
| `content` | string | ✅ Yes | Article content (HTML) |
| `status` | string | No | `draft`, `pending`, or `publish` (default: `draft`) |
| `excerpt` | string | No | Article excerpt/summary |
| `categories` | array | No | Category names or IDs |
| `tags` | array | No | Tag names |
| `featured_image_url` | string | No | URL of featured image |
| `featured_image` | object | No | Featured image with metadata (url, alt, caption, title) |
| `images` | array | No | Content images with placeholders |
| `meta` | object | No | Custom meta fields |

### Success Response

```json
{
  "success": true,
  "message": "Article created successfully.",
  "post_id": 123,
  "post_url": "https://yoursite.com/my-article/",
  "edit_url": "https://yoursite.com/wp-admin/post.php?post=123&action=edit",
  "status": "draft"
}
```

### Health Check

```bash
curl "https://yoursite.com/wp-json/searchfit/v1/health" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY"
```

## 🎯 Use Cases

- **AI Content Generation** - Connect ChatGPT, Claude, or Perplexity to WordPress
- **Answer Engine Optimization (AEO)** - Create content optimized for AI search
- **Marketing Automation** - Integrate with Zapier, Make, n8n, and more
- **Content Syndication** - Automated content distribution
- **Headless WordPress** - External CMS and decoupled setups

## 📋 Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- REST API enabled (default in WordPress)

## 🔒 Security

SearchFIT uses:
- Cryptographically secure API key generation (`random_bytes()`)
- Timing-safe comparison to prevent timing attacks
- WordPress nonce verification for admin actions
- Proper capability checks for all operations
- Sanitization and validation of all inputs

## 📁 Plugin Structure

```
searchfit-wp/
├── admin/
│   └── views/
│       └── admin-page.php
├── assets/
│   ├── css/
│   ├── images/
│   └── js/
├── includes/
│   └── class-searchfit-webhook.php
├── languages/
│   └── searchfit.pot
├── .wordpress-org/          # Assets for WordPress.org
├── LICENSE
├── readme.txt               # WordPress.org readme
├── README.md                # GitHub readme
├── searchfit.php            # Main plugin file
└── uninstall.php
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

GPL v2 or later - see [LICENSE](LICENSE) for details.

## 🔗 Links

- [SearchFIT Website](https://searchfit.ai)
- [Documentation](https://searchfit.ai/docs)
- [Support](https://wordpress.org/support/plugin/searchfit/)

---

Made with ❤️ by [SearchFIT](https://searchfit.ai)
