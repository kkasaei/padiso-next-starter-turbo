<?php
/**
 * SearchFIT Webhook Handler Class
 *
 * Handles incoming webhook requests for article submissions.
 *
 * @package SearchFIT
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SearchFIT_Webhook
 *
 * @since 1.0.0
 */
class SearchFIT_Webhook {

    /**
     * REST API namespace.
     *
     * @var string
     */
    const API_NAMESPACE = 'searchfit/v1';

    /**
     * Instance of this class.
     *
     * @var SearchFIT_Webhook
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     *
     * @return SearchFIT_Webhook
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Register REST API routes.
     */
    public function register_routes() {
        register_rest_route(
            self::API_NAMESPACE,
            '/articles',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'handle_article_submission' ),
                'permission_callback' => array( $this, 'verify_api_key' ),
                'args'                => $this->get_article_args(),
            )
        );

        register_rest_route(
            self::API_NAMESPACE,
            '/health',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'health_check' ),
                'permission_callback' => array( $this, 'verify_api_key' ),
            )
        );
    }

    /**
     * Get article endpoint arguments.
     *
     * @return array
     */
    private function get_article_args() {
        return array(
            'title'              => array(
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => __( 'The article title.', 'searchfit' ),
            ),
            'content'            => array(
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'wp_kses_post',
                'description'       => __( 'The article content (HTML allowed).', 'searchfit' ),
            ),
            'status'             => array(
                'required'          => false,
                'type'              => 'string',
                'default'           => 'draft',
                'enum'              => array( 'draft', 'publish', 'pending' ),
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => __( 'The post status.', 'searchfit' ),
            ),
            'excerpt'            => array(
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_textarea_field',
                'description'       => __( 'The article excerpt.', 'searchfit' ),
            ),
            'categories'         => array(
                'required'    => false,
                'type'        => 'array',
                'items'       => array( 'type' => 'string' ),
                'description' => __( 'Array of category names or IDs.', 'searchfit' ),
            ),
            'tags'               => array(
                'required'    => false,
                'type'        => 'array',
                'items'       => array( 'type' => 'string' ),
                'description' => __( 'Array of tag names.', 'searchfit' ),
            ),
            'featured_image_url' => array(
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'esc_url_raw',
                'description'       => __( 'URL of the featured image.', 'searchfit' ),
            ),
            'featured_image'     => array(
                'required'    => false,
                'type'        => 'object',
                'description' => __( 'Featured image with metadata.', 'searchfit' ),
            ),
            'images'             => array(
                'required'    => false,
                'type'        => 'array',
                'description' => __( 'Array of content images.', 'searchfit' ),
            ),
            'meta'               => array(
                'required'    => false,
                'type'        => 'object',
                'description' => __( 'Custom meta fields.', 'searchfit' ),
            ),
        );
    }

    /**
     * Verify API key from request header.
     *
     * @param WP_REST_Request $request The request object.
     * @return bool|WP_Error
     */
    public function verify_api_key( $request ) {
        $api_key = $request->get_header( 'X-SearchFIT-API-Key' );

        // Also check Authorization header with Bearer token.
        if ( empty( $api_key ) ) {
            $auth_header = $request->get_header( 'Authorization' );
            if ( $auth_header && 0 === strpos( $auth_header, 'Bearer ' ) ) {
                $api_key = substr( $auth_header, 7 );
            }
        }

        if ( empty( $api_key ) ) {
            return new WP_Error(
                'missing_api_key',
                __( 'API key is required. Include it in the X-SearchFIT-API-Key header.', 'searchfit' ),
                array( 'status' => 401 )
            );
        }

        $stored_api_key = get_option( 'searchfit_webhook_api_key', '' );

        if ( empty( $stored_api_key ) ) {
            return new WP_Error(
                'api_key_not_configured',
                __( 'API key has not been configured on this site.', 'searchfit' ),
                array( 'status' => 500 )
            );
        }

        if ( ! hash_equals( $stored_api_key, $api_key ) ) {
            return new WP_Error(
                'invalid_api_key',
                __( 'Invalid API key.', 'searchfit' ),
                array( 'status' => 401 )
            );
        }

        return true;
    }

    /**
     * Handle article submission webhook.
     *
     * @param WP_REST_Request $request The request object.
     * @return WP_REST_Response|WP_Error
     */
    public function handle_article_submission( $request ) {
        $title   = $request->get_param( 'title' );
        $content = $request->get_param( 'content' );
        $status  = $request->get_param( 'status' ) ? $request->get_param( 'status' ) : 'draft';
        $excerpt = $request->get_param( 'excerpt' );

        // Track uploaded images for response.
        $uploaded_images = array();

        // Process content images first (replace placeholders).
        $images = $request->get_param( 'images' );
        if ( ! empty( $images ) && is_array( $images ) ) {
            $content = $this->process_content_images( $content, $images, 0, $uploaded_images );
        }

        // Prepare post data.
        $post_data = array(
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'post',
            'post_author'  => $this->get_default_author_id(),
        );

        if ( ! empty( $excerpt ) ) {
            $post_data['post_excerpt'] = $excerpt;
        }

        // Insert the post.
        $post_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $post_id ) ) {
            return new WP_Error(
                'post_creation_failed',
                $post_id->get_error_message(),
                array( 'status' => 500 )
            );
        }

        // Re-process content images now that we have post_id (to attach them).
        if ( ! empty( $images ) && is_array( $images ) ) {
            $uploaded_images = array();
            $updated_content = $this->process_content_images(
                $request->get_param( 'content' ),
                $images,
                $post_id,
                $uploaded_images
            );
            wp_update_post(
                array(
                    'ID'           => $post_id,
                    'post_content' => $updated_content,
                )
            );
        }

        // Handle categories.
        $categories = $request->get_param( 'categories' );
        if ( ! empty( $categories ) && is_array( $categories ) ) {
            $category_ids = $this->process_categories( $categories );
            if ( ! empty( $category_ids ) ) {
                wp_set_post_categories( $post_id, $category_ids );
            }
        }

        // Handle tags.
        $tags = $request->get_param( 'tags' );
        if ( ! empty( $tags ) && is_array( $tags ) ) {
            wp_set_post_tags( $post_id, $tags );
        }

        // Handle featured image.
        $featured_image_result = $this->handle_featured_image( $post_id, $request );

        // Handle custom meta.
        $meta = $request->get_param( 'meta' );
        if ( ! empty( $meta ) && is_array( $meta ) ) {
            foreach ( $meta as $key => $value ) {
                $meta_key = 'searchfit_' . sanitize_key( $key );
                update_post_meta( $post_id, $meta_key, $value );
            }
        }

        // Mark post as created via SearchFIT webhook.
        update_post_meta( $post_id, '_searchfit_webhook_created', true );
        update_post_meta( $post_id, '_searchfit_webhook_created_at', current_time( 'mysql' ) );

        // Store image count.
        $total_images = count( $uploaded_images ) + ( $featured_image_result ? 1 : 0 );
        update_post_meta( $post_id, '_searchfit_images_count', $total_images );

        // Log the creation.
        $this->log_webhook_activity(
            'article_created',
            array(
                'post_id'      => $post_id,
                'title'        => $title,
                'status'       => $status,
                'images_count' => $total_images,
            )
        );

        // Get the created post.
        $post = get_post( $post_id );

        return new WP_REST_Response(
            array(
                'success'    => true,
                'message'    => __( 'Article created successfully.', 'searchfit' ),
                'post_id'    => $post_id,
                'post_url'   => get_permalink( $post_id ),
                'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
                'status'     => $post->post_status,
                'created_at' => $post->post_date,
                'images'     => array(
                    'featured'       => $featured_image_result,
                    'content_images' => $uploaded_images,
                    'total_count'    => $total_images,
                ),
            ),
            201
        );
    }

    /**
     * Handle featured image upload.
     *
     * @param int             $post_id The post ID.
     * @param WP_REST_Request $request The request object.
     * @return array|false
     */
    private function handle_featured_image( $post_id, $request ) {
        $featured_image     = $request->get_param( 'featured_image' );
        $featured_image_url = $request->get_param( 'featured_image_url' );

        if ( ! empty( $featured_image ) && is_array( $featured_image ) && ! empty( $featured_image['url'] ) ) {
            return $this->upload_image_with_metadata( $post_id, $featured_image, true );
        } elseif ( ! empty( $featured_image_url ) ) {
            return $this->upload_image_with_metadata( $post_id, array( 'url' => $featured_image_url ), true );
        }

        return false;
    }

    /**
     * Upload an image with metadata.
     *
     * @param int   $post_id      The post ID to attach to.
     * @param array $image_data   Image data with url, alt, caption, title, description.
     * @param bool  $set_featured Whether to set as featured image.
     * @return array|false Array with attachment info on success, false on failure.
     */
    private function upload_image_with_metadata( $post_id, $image_data, $set_featured = false ) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $url = isset( $image_data['url'] ) ? $image_data['url'] : '';

        if ( empty( $url ) ) {
            return false;
        }

        // Download the image.
        $tmp = download_url( $url );

        if ( is_wp_error( $tmp ) ) {
            return false;
        }

        // Get file info.
        $filename = basename( wp_parse_url( $url, PHP_URL_PATH ) );

        // If no extension, default to jpg.
        if ( ! pathinfo( $filename, PATHINFO_EXTENSION ) ) {
            $filename .= '.jpg';
        }

        $file_array = array(
            'name'     => $filename,
            'tmp_name' => $tmp,
        );

        // Prepare attachment data.
        $attachment_data = array();

        if ( ! empty( $image_data['title'] ) ) {
            $attachment_data['post_title'] = sanitize_text_field( $image_data['title'] );
        }

        if ( ! empty( $image_data['caption'] ) ) {
            $attachment_data['post_excerpt'] = sanitize_textarea_field( $image_data['caption'] );
        }

        if ( ! empty( $image_data['description'] ) ) {
            $attachment_data['post_content'] = sanitize_textarea_field( $image_data['description'] );
        }

        // Upload the image.
        $attachment_id = media_handle_sideload( $file_array, $post_id, null, $attachment_data );

        // Clean up temp file.
        if ( file_exists( $tmp ) ) {
            wp_delete_file( $tmp );
        }

        if ( is_wp_error( $attachment_id ) ) {
            return false;
        }

        // Set alt text.
        if ( ! empty( $image_data['alt'] ) ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $image_data['alt'] ) );
        }

        // Set as featured image if requested.
        if ( $set_featured ) {
            set_post_thumbnail( $post_id, $attachment_id );
        }

        return array(
            'attachment_id' => $attachment_id,
            'url'           => wp_get_attachment_url( $attachment_id ),
            'alt'           => isset( $image_data['alt'] ) ? $image_data['alt'] : '',
            'caption'       => isset( $image_data['caption'] ) ? $image_data['caption'] : '',
            'title'         => isset( $image_data['title'] ) ? $image_data['title'] : '',
        );
    }

    /**
     * Process content images and replace placeholders.
     *
     * @param string $content         The post content.
     * @param array  $images          Array of image data.
     * @param int    $post_id         The post ID (0 if not yet created).
     * @param array  $uploaded_images Reference to track uploaded images.
     * @return string Modified content with image HTML.
     */
    private function process_content_images( $content, $images, $post_id, &$uploaded_images ) {
        foreach ( $images as $image ) {
            if ( empty( $image['placeholder'] ) || empty( $image['url'] ) ) {
                continue;
            }

            $placeholder = $image['placeholder'];

            // Upload the image.
            $result = $this->upload_image_with_metadata( $post_id, $image, false );

            if ( ! $result ) {
                // If upload failed, remove placeholder.
                $content = str_replace( $placeholder, '', $content );
                continue;
            }

            $uploaded_images[] = $result;

            // Build image HTML.
            $img_html = $this->build_image_html( $result, $image );

            // Replace placeholder with image HTML.
            $content = str_replace( $placeholder, $img_html, $content );
        }

        return $content;
    }

    /**
     * Build image HTML with optional figure/figcaption.
     *
     * @param array $result     Upload result with attachment info.
     * @param array $image_data Original image data.
     * @return string Image HTML.
     */
    private function build_image_html( $result, $image_data ) {
        $attachment_id = $result['attachment_id'];
        $alt           = esc_attr( $result['alt'] );
        $caption       = isset( $image_data['caption'] ) ? $image_data['caption'] : '';
        $link          = isset( $image_data['link'] ) ? esc_url( $image_data['link'] ) : '';
        $align         = isset( $image_data['align'] ) ? $image_data['align'] : 'none';
        $size          = isset( $image_data['size'] ) ? $image_data['size'] : 'large';

        // Get image at specified size.
        $img_src    = wp_get_attachment_image_src( $attachment_id, $size );
        $img_url    = $img_src ? $img_src[0] : $result['url'];
        $img_width  = $img_src ? $img_src[1] : '';
        $img_height = $img_src ? $img_src[2] : '';

        // Build img tag.
        $img_attrs = array(
            'src'   => esc_url( $img_url ),
            'alt'   => $alt,
            'class' => 'wp-image-' . $attachment_id,
        );

        if ( $img_width ) {
            $img_attrs['width'] = $img_width;
        }
        if ( $img_height ) {
            $img_attrs['height'] = $img_height;
        }

        $img_tag = '<img';
        foreach ( $img_attrs as $attr => $value ) {
            $img_tag .= ' ' . $attr . '="' . esc_attr( $value ) . '"';
        }
        $img_tag .= ' />';

        // Wrap in link if provided.
        if ( $link ) {
            $img_tag = '<a href="' . $link . '">' . $img_tag . '</a>';
        }

        // Build block HTML.
        $align_class = 'none' !== $align ? ' align' . $align : '';

        $html  = '<!-- wp:image {"id":' . $attachment_id . ',"sizeSlug":"' . esc_attr( $size ) . '"} -->';
        $html .= '<figure class="wp-block-image size-' . esc_attr( $size ) . $align_class . '">';
        $html .= $img_tag;

        if ( ! empty( $caption ) ) {
            $html .= '<figcaption class="wp-element-caption">' . wp_kses_post( $caption ) . '</figcaption>';
        }

        $html .= '</figure>';
        $html .= '<!-- /wp:image -->';

        return $html;
    }

    /**
     * Health check endpoint.
     *
     * @param WP_REST_Request $request The request object.
     * @return WP_REST_Response
     */
    public function health_check( $request ) {
        return new WP_REST_Response(
            array(
                'success' => true,
                'message' => __( 'SearchFIT webhook is operational.', 'searchfit' ),
                'version' => SEARCHFIT_VERSION,
                'site'    => get_bloginfo( 'name' ),
                'time'    => current_time( 'c' ),
            ),
            200
        );
    }

    /**
     * Get default author ID for webhook-created posts.
     *
     * @return int
     */
    private function get_default_author_id() {
        $admins = get_users(
            array(
                'role'    => 'administrator',
                'number'  => 1,
                'orderby' => 'ID',
                'order'   => 'ASC',
            )
        );

        if ( ! empty( $admins ) ) {
            return $admins[0]->ID;
        }

        return 1;
    }

    /**
     * Process category names/IDs and return category IDs.
     *
     * @param array $categories Array of category names or IDs.
     * @return array Category IDs.
     */
    private function process_categories( $categories ) {
        $category_ids = array();

        foreach ( $categories as $category ) {
            if ( is_numeric( $category ) ) {
                $term = get_term( (int) $category, 'category' );
                if ( $term && ! is_wp_error( $term ) ) {
                    $category_ids[] = (int) $category;
                }
            } else {
                $term = get_term_by( 'name', $category, 'category' );
                if ( $term ) {
                    $category_ids[] = $term->term_id;
                } else {
                    $new_term = wp_insert_term( $category, 'category' );
                    if ( ! is_wp_error( $new_term ) ) {
                        $category_ids[] = $new_term['term_id'];
                    }
                }
            }
        }

        return $category_ids;
    }

    /**
     * Log webhook activity.
     *
     * @param string $action The action being logged.
     * @param array  $data   Additional data to log.
     */
    private function log_webhook_activity( $action, $data = array() ) {
        $log = get_option( 'searchfit_webhook_log', array() );

        // Keep only the last 100 entries.
        if ( count( $log ) >= 100 ) {
            $log = array_slice( $log, -99 );
        }

        $log[] = array(
            'action'    => $action,
            'data'      => $data,
            'timestamp' => current_time( 'mysql' ),
            'ip'        => $this->get_client_ip(),
        );

        update_option( 'searchfit_webhook_log', $log, false );
    }

    /**
     * Get client IP address.
     *
     * @return string
     */
    private function get_client_ip() {
        $ip = '';

        // phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotValidated
        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CLIENT_IP'] ) );
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
        } elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
        }
        // phpcs:enable

        return $ip;
    }

    /**
     * Generate a secure API key.
     *
     * @return string
     */
    public static function generate_api_key() {
        $bytes = random_bytes( 32 );
        return 'sf_' . bin2hex( $bytes );
    }

    /**
     * Get the webhook URL.
     *
     * @return string
     */
    public static function get_webhook_url() {
        return rest_url( self::API_NAMESPACE . '/articles' );
    }

    /**
     * Get the health check URL.
     *
     * @return string
     */
    public static function get_health_url() {
        return rest_url( self::API_NAMESPACE . '/health' );
    }
}

// Initialize the webhook handler.
SearchFIT_Webhook::get_instance();
