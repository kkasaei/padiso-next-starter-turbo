<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package SearchFIT
 * @since   1.0.0
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options.
delete_option( 'searchfit_options' );
delete_option( 'searchfit_version' );
delete_option( 'searchfit_webhook_api_key' );
delete_option( 'searchfit_webhook_log' );

// Delete post meta for webhook-created posts.
global $wpdb;
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_searchfit_webhook_created' ) );
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_searchfit_webhook_created_at' ) );
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_searchfit_images_count' ) );

// Clear any cached data.
wp_cache_flush();
