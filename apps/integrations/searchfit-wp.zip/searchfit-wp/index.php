<?php
/**
 * Silence is golden.
 *
 * @package SearchFIT
 */
