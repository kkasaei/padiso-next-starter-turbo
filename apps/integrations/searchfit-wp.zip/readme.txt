=== SearchFIT ===
Contributors: searchfit
Tags: seo, ai, aeo, geo, content automation
Requires at least: 5.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Receive articles via webhook API to automatically create WordPress posts with images, categories, and tags.

== Description ==

SearchFIT provides a secure webhook API endpoint that allows you to programmatically create WordPress posts from external services, automation tools, or custom applications. Perfect for AI-powered content workflows with ChatGPT, Claude, Perplexity, and other AI assistants.

Optimize your content for AI search engines (AEO - Answer Engine Optimization) and generative search (GEO - Generative Engine Optimization) by automating your content pipeline.

**Features:**

* **Secure API Key Authentication** - Auto-generated API keys with regeneration support
* **Full Post Creation** - Create posts with title, content, excerpt, categories, and tags
* **Image Support** - Automatically download and attach featured images and content images
* **Draft Mode** - Create posts as drafts, pending review, or publish immediately
* **Health Check Endpoint** - Verify API connectivity

**Use Cases:**

* AI content generation with ChatGPT, Claude, Perplexity
* Answer Engine Optimization (AEO) workflows
* Generative Engine Optimization (GEO) strategies
* Automated SEO content pipelines
* External CMS and headless setups
* Content syndication and automation

== Installation ==

1. Upload the `searchfit` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to SearchFIT in the admin menu to view your API credentials
4. Use the API key and webhook URL in your external service

== Usage ==

**Create an Article:**

Send a POST request to `/wp-json/searchfit/v1/articles` with your API key:

`
curl -X POST "https://yoursite.com/wp-json/searchfit/v1/articles" \
  -H "Content-Type: application/json" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY" \
  -d '{
    "title": "My Article Title",
    "content": "<p>Article content here...</p>",
    "status": "draft",
    "categories": ["News", "Updates"],
    "tags": ["important", "announcement"]
  }'
`

**Check API Status:**

`
curl "https://yoursite.com/wp-json/searchfit/v1/health" \
  -H "X-SearchFIT-API-Key: YOUR_API_KEY"
`

== Screenshots ==

1. SearchFIT dashboard with API credentials - Copy your API key and webhook URL with one click
2. API Documentation panel - Interactive documentation with code examples
3. Endpoint reference - View all available endpoints with their methods
4. Request parameters - Complete reference of all supported fields
5. Example response - See what the API returns after creating a post

== Frequently Asked Questions ==

= How do I get my API key? =

After activating the plugin, go to SearchFIT in your WordPress admin menu. Your API key is displayed there and can be copied with one click.

= Can I regenerate my API key? =

Yes, click "Regenerate API Key" on the settings page. Note that the old key will stop working immediately.

= What post statuses are supported? =

You can create posts with status: `draft`, `pending`, or `publish`.

= How do featured images work? =

Include a `featured_image_url` parameter with a public image URL. The plugin will download and attach it as the featured image.

= Is the API secure? =

Yes! All requests require a valid API key. Keys are auto-generated using cryptographically secure methods and can be regenerated at any time.

= Can I use this with AI tools? =

Absolutely! SearchFIT is designed for AI-powered workflows. Use it with ChatGPT, Claude, Perplexity, or any service that can make HTTP requests.

== Changelog ==

= 1.0.0 =
* Initial release
* Webhook API for article creation
* API key authentication
* Image upload support
* Categories and tags support

== Upgrade Notice ==

= 1.0.0 =
Initial release.
